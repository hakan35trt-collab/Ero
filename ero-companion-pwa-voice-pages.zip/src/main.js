import 'boopface';
import './style.css';
const avatar=document.querySelector('#avatar'), messages=document.querySelector('#messages'), form=document.querySelector('#chatform'), input=document.querySelector('#prompt'), mood=document.querySelector('#mood');
const expressions={affirm:'affirm',love:'love',surprise:'surprise',angry:'angry',sleep:'sleep',wake:'wake'};
const voiceSelect=document.querySelector('#voice'), voiceToggle=document.querySelector('#voiceToggle'), stopVoice=document.querySelector('#stopVoice');
let voiceOn=true, voices=[];
function loadVoices(){if(!('speechSynthesis' in window)) {voiceToggle.disabled=true;voiceToggle.textContent='Ses desteklenmiyor';return;}
 voices=speechSynthesis.getVoices();voiceSelect.innerHTML='';
 const tr=voices.filter(v=>v.lang.toLowerCase().startsWith('tr'));
 (tr.length?tr:voices).forEach(v=>{const o=document.createElement('option');o.value=v.name;o.textContent=v.name+' · '+v.lang;voiceSelect.append(o)});
}
function speak(text){if(!voiceOn||!('speechSynthesis' in window))return;speechSynthesis.cancel();const utter=new SpeechSynthesisUtterance(text);utter.lang='tr-TR';utter.rate=.96;utter.pitch=.88;utter.volume=1;const v=voices.find(v=>v.name===voiceSelect.value)||voices.find(v=>v.lang.toLowerCase().startsWith('tr'));if(v)utter.voice=v;speechSynthesis.speak(utter);}
voiceToggle.onclick=()=>{voiceOn=!voiceOn;voiceToggle.textContent=voiceOn?'🔊 Ses açık':'🔇 Ses kapalı';if(!voiceOn)speechSynthesis.cancel()};
stopVoice.onclick=()=>speechSynthesis.cancel();loadVoices();if('speechSynthesis'in window)speechSynthesis.onvoiceschanged=loadVoices;
function play(action){try{avatar.play(action);mood.textContent='ERO · '+({affirm:'Anladım',love:'Sevgi',surprise:'Şaşkın',angry:'Sinirli',sleep:'Uyuyor',wake:'Uyandı'}[action]||action)}catch(e){}}
document.querySelectorAll('[data-action]').forEach(b=>b.addEventListener('click',()=>play(b.dataset.action)));
function addMessage(text,who){const div=document.createElement('div');div.className='msg '+who;const n=document.createElement('span');n.className='name';n.textContent=who==='ero'?'ERO':'SEN';div.append(n,document.createTextNode(text));messages.append(div);messages.scrollTop=messages.scrollHeight;}
function demoReply(text){const t=text.toLowerCase();if(/merhaba|selam|hey/.test(t))return 'Selam! Buradayım. 👀';if(/nasılsın|naber/.test(t))return 'İyiyim, şu an seninle konuşmaya hazırım. Sen nasılsın?';if(/adın|ismin/.test(t))return 'Ben ERO. Henüz ilk prototipim ama birlikte geliştireceğiz.';if(/uyku|yor/.test(t)){play('sleep');return 'Biraz sakinleşiyorum… İstersen beni uyandırabilirsin.'}if(/sev|💛/.test(t)){play('love');return '💛 Bunu güzel bir mesaj olarak algıladım.'}play('affirm');return 'Mesajını aldım. Şimdilik demo modundayım; gerçek yapay zekâ bağlantısı eklendiğinde daha kapsamlı yanıt verebileceğim.'}
form.addEventListener('submit',e=>{e.preventDefault();const text=input.value.trim();if(!text)return;addMessage(text,'user');input.value='';play('input');setTimeout(()=>{const reply=demoReply(text);addMessage(reply,'ero');speak(reply);if(!/uyku/.test(text.toLowerCase()))play('affirm');},400);});
if('serviceWorker' in navigator)window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));
let installPrompt;const installBtn=document.querySelector('#install');window.addEventListener('beforeinstallprompt',e=>{e.preventDefault();installPrompt=e;installBtn.classList.remove('hidden')});installBtn.addEventListener('click',async()=>{if(!installPrompt)return;installPrompt.prompt();await installPrompt.userChoice;installPrompt=null;installBtn.classList.add('hidden')});
