# ERO Companion PWA (starter)

Mobile-first PWA prototype using **BoopFace** as the ready-made animated avatar component. The avatar package is MIT-licensed; its original character art/identity is not rebranded as ERO. BoopFace is used as a third-party avatar component.

## Features
- Responsive dark/gold mobile interface
- BoopFace expressions and actions
- Demo chat (local sample responses only)
- PWA manifest and service worker
- GitHub Pages deployment workflow

## Run locally
1. Install Node.js 20+
2. `npm install`
3. `npm run dev`

## Deploy on GitHub Pages
1. Create a repository and upload these project files to the `main` branch.
2. In Settings → Pages, set source to **GitHub Actions**.
3. Push to `main`; the included workflow builds and deploys automatically.

## Important: AI is not connected yet
The chat is currently a UI/demo with local example responses. For a real AI model, connect a backend proxy (never place a private API key in frontend code). Add a backend endpoint and route chat requests through it. Free options depend on provider limits and availability.

## BoopFace
Project: https://github.com/CX-ArtLab/BoopFace
Official site: https://boopface.com
The project is MIT licensed. Keep its license and notices when redistributing. BoopFace's character/visual identity remains the original author's; this starter does not claim it as ERO's original artwork.

## Free voice

The app uses the device/browser built-in SpeechSynthesis (no paid API key). Voice options depend on Android/Chrome installed voices; choose Turkish if available. Voice is enabled by default and can be toggled or stopped in the chat.

## GitHub Pages note

The repository is named `Ero`; GitHub Pages should be configured in Settings → Pages → Build and deployment → Source: GitHub Actions. The workflow deploys on pushes to `main`.
